cp ../vacancy2_density/charges.bin .
dftb+ | tee output.dftb+
