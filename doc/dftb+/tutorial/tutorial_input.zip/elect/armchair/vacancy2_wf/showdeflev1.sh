jmol -L -s showdeflev1.js &
