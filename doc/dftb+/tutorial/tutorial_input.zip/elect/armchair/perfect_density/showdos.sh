grep "Fermi energy" detailed.out
plotxy --xlabel "Energy [eV]" --ylabel "DOS" dos.dat &
