dftb+ | tee output
dp_dos -b .05 band.out dos.dat
